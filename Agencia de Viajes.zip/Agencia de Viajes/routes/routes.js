import express from "express";

//objeto ruteador.
const router = express.Router();

//Ruta para pagina index (default)
router.get('/', (req, res) => {
    res.render("inicio", {
        pagina: 'Inicio'
    });
});

//Ruta para pagina de contactos.
router.get('/nosotros', (req, res) => {
    res.render("nosotros", {
        pagina: 'Nosotros'
    });
});

//Ruta para testimoniales
router.get('/testimoniales', (req, res) => {
    res.render("testimoniales", {
        pagina: 'Testimoniales'
    });
});

//ruta para viajes.
router.get('/viajes', (req, res) => {
    res.render("viajes",{
        pagina: "Viajes"
    });
});




export default router;